import React, { useMemo, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Box,
  CheckCircle2,
  Hammer,
  Heart,
  Image as ImageIcon,
  Scissors,
  Smile,
  Sparkles,
  Sticker as StickerIcon,
} from 'lucide-react';
import { CollectedItem, ExhibitionHall } from '../types';
import { getHallNameById } from '../services/halls';

export type WorkshopToolId = 'EMOJI_PACK' | 'PERLER_PATTERN' | 'PRINT' | 'GUIDE';

export interface WorkshopLaunchRequest {
  tool: WorkshopToolId;
  items: CollectedItem[];
}

interface RegenerationWorkshopProps {
  items: CollectedItem[];
  halls: ExhibitionHall[];
  resultStats: {
    stickers: number;
    emojiPacks: number;
    perlerPatterns: number;
  };
  onLaunchTool: (request: WorkshopLaunchRequest) => Promise<void> | void;
  onOpenLibrary: () => void;
}

interface WorkshopToolConfig {
  id: WorkshopToolId;
  lane: 'PLAYFUL' | 'HEART' | 'RENEWAL';
  title: string;
  subtitle: string;
  description: string;
  badge: string;
  cta: string;
  selectionLimit: number;
  requiresVisual: boolean;
  icon: React.ReactNode;
  accentClassName: string;
  panelClassName: string;
  helper: string;
}

const collectionDateFormatter = new Intl.DateTimeFormat('zh-CN', {
  month: 'numeric',
  day: 'numeric',
});

const TOOL_CONFIGS: Record<WorkshopToolId, WorkshopToolConfig> = {
  EMOJI_PACK: {
    id: 'EMOJI_PACK',
    lane: 'PLAYFUL',
    title: '表情包',
    subtitle: '妙趣灵感社',
    description: '收集可爱与创意，把日常变得有趣。',
    badge: 'FUN LINE',
    cta: '选藏品做表情包',
    selectionLimit: 6,
    requiresVisual: true,
    icon: <Smile size={18} />,
    accentClassName: 'text-amber-300',
    panelClassName:
      'border-amber-400/20 bg-[radial-gradient(circle_at_top_right,rgba(251,191,36,0.14),transparent_36%),linear-gradient(180deg,rgba(25,21,15,0.94),rgba(12,11,9,0.96))]',
    helper: '支持多选，系统会优先复用已有贴纸，没有贴纸时自动生成。',
  },
  PERLER_PATTERN: {
    id: 'PERLER_PATTERN',
    lane: 'PLAYFUL',
    title: '拼豆图纸',
    subtitle: '妙趣灵感社',
    description: '把喜欢的形象转成可落地制作的像素图纸。',
    badge: 'FUN LINE',
    cta: '选 1 件藏品做拼豆图纸',
    selectionLimit: 1,
    requiresVisual: true,
    icon: <Box size={18} />,
    accentClassName: 'text-cyan-300',
    panelClassName:
      'border-cyan-400/20 bg-[radial-gradient(circle_at_top_right,rgba(34,211,238,0.14),transparent_36%),linear-gradient(180deg,rgba(14,22,27,0.94),rgba(8,12,15,0.96))]',
    helper: '需要单件藏品，系统会自动准备图像贴纸后进入图纸工坊。',
  },
  PRINT: {
    id: 'PRINT',
    lane: 'HEART',
    title: '手账拼贴',
    subtitle: '心灵自留地',
    description: '安放情绪与温柔，给自己一片安静角落。',
    badge: 'SOFT LINE',
    cta: '选藏品做手账拼贴',
    selectionLimit: 6,
    requiresVisual: true,
    icon: <Scissors size={18} />,
    accentClassName: 'text-sky-300',
    panelClassName:
      'border-sky-400/20 bg-[radial-gradient(circle_at_top_right,rgba(56,189,248,0.14),transparent_36%),linear-gradient(180deg,rgba(13,20,28,0.94),rgba(7,10,15,0.96))]',
    helper: '支持多选，系统会自动整理为可继续编辑的手账拼贴素材。',
  },
  GUIDE: {
    id: 'GUIDE',
    lane: 'RENEWAL',
    title: '改造指南',
    subtitle: '旧物新生局',
    description: '让旧物重获新生，换种形式陪伴你。',
    badge: 'REMAKE LINE',
    cta: '选 1 件藏品做改造指南',
    selectionLimit: 1,
    requiresVisual: false,
    icon: <Hammer size={18} />,
    accentClassName: 'text-remuse-accent',
    panelClassName:
      'border-remuse-accent/20 bg-[radial-gradient(circle_at_top_right,rgba(204,255,0,0.14),transparent_36%),linear-gradient(180deg,rgba(18,24,16,0.94),rgba(10,12,9,0.96))]',
    helper: '单件进入，直接打开旧物改造工作台。',
  },
};

function formatCollectionDate(value: string) {
  const timestamp = Date.parse(value);
  if (Number.isNaN(timestamp)) {
    return value;
  }

  return collectionDateFormatter.format(new Date(timestamp));
}

const RegenerationWorkshop: React.FC<RegenerationWorkshopProps> = ({
  items = [],
  halls = [],
  resultStats,
  onLaunchTool,
  onOpenLibrary,
}) => {
  const safeItems = Array.isArray(items) ? items : [];
  const safeHalls = Array.isArray(halls) ? halls : [];
  const [activeToolId, setActiveToolId] = useState<WorkshopToolId | null>(null);
  const [selectedHallId, setSelectedHallId] = useState<string | null>(null);
  const [selectedItemIds, setSelectedItemIds] = useState<string[]>([]);
  const [launchError, setLaunchError] = useState<string | null>(null);
  const [isLaunching, setIsLaunching] = useState(false);

  const sortedItems = useMemo(
    () =>
      safeItems.slice().sort((left, right) => {
        const leftTime = Date.parse(left.dateCollected) || 0;
        const rightTime = Date.parse(right.dateCollected) || 0;
        return rightTime - leftTime;
      }),
    [safeItems],
  );

  const activeTool = activeToolId ? TOOL_CONFIGS[activeToolId] : null;
  const filteredItems = useMemo(() => {
    return selectedHallId
      ? sortedItems.filter((item) => item.hallId === selectedHallId)
      : sortedItems;
  }, [selectedHallId, sortedItems]);

  const selectedItems = useMemo(() => {
    if (selectedItemIds.length === 0) {
      return [];
    }

    const itemMap = new Map(sortedItems.map((item) => [item.id, item]));
    return selectedItemIds
      .map((id) => itemMap.get(id))
      .filter(Boolean) as CollectedItem[];
  }, [selectedItemIds, sortedItems]);

  const filterOptions = useMemo(
    () => [
      { id: null as string | null, label: '全部', count: sortedItems.length },
      ...safeHalls.map((hall) => ({
        id: hall.id,
        label: hall.name,
        count: sortedItems.filter((item) => item.hallId === hall.id).length,
      })),
    ],
    [safeHalls, sortedItems],
  );

  const visualReadyCount = useMemo(
    () => safeItems.filter((item) => item.imageUrl || item.coverImageUrl).length,
    [safeItems],
  );

  const openPicker = (toolId: WorkshopToolId) => {
    setActiveToolId(toolId);
    setSelectedHallId(null);
    setSelectedItemIds([]);
    setLaunchError(null);
  };

  const closePicker = () => {
    setActiveToolId(null);
    setSelectedHallId(null);
    setSelectedItemIds([]);
    setLaunchError(null);
    setIsLaunching(false);
  };

  const toggleItemSelection = (itemId: string) => {
    if (!activeTool) {
      return;
    }

    setSelectedItemIds((previous) => {
      if (previous.includes(itemId)) {
        return previous.filter((id) => id !== itemId);
      }

      if (activeTool.selectionLimit === 1) {
        return [itemId];
      }

      if (previous.length >= activeTool.selectionLimit) {
        return previous;
      }

      return [...previous, itemId];
    });
  };

  const canUseItem = (item: CollectedItem) => {
    if (!activeTool) {
      return false;
    }

    if (!activeTool.requiresVisual) {
      return true;
    }

    return Boolean(item.imageUrl || item.coverImageUrl);
  };

  const handleLaunch = async () => {
    if (!activeTool || selectedItems.length === 0) {
      return;
    }

    setIsLaunching(true);
    setLaunchError(null);

    try {
      await onLaunchTool({
        tool: activeTool.id,
        items: selectedItems,
      });
    } catch (error) {
      setLaunchError(error instanceof Error ? error.message : '再生流程启动失败，请稍后重试。');
      setIsLaunching(false);
    }
  };

  if (activeTool) {
    return (
      <div className="h-full overflow-y-auto bg-remuse-dark p-4 pb-28 md:p-8">
        <div className="mx-auto max-w-[1480px] space-y-6">
          <section className="rounded-[30px] border border-remuse-border bg-[radial-gradient(circle_at_top_left,rgba(255,255,255,0.06),transparent_32%),linear-gradient(180deg,rgba(18,21,26,0.98),rgba(8,10,13,0.98))] p-5 shadow-[0_20px_60px_rgba(0,0,0,0.26)] md:p-7">
            <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
              <div className="space-y-4">
                <button
                  type="button"
                  onClick={closePicker}
                  className="inline-flex min-h-[44px] items-center gap-2 rounded-full border border-neutral-700 px-4 text-sm text-neutral-300 transition-colors hover:border-white hover:text-white"
                >
                  <ArrowLeft size={16} />
                  返回再生工坊
                </button>
                <div className="space-y-3">
                  <div className={`inline-flex items-center gap-2 rounded-full border px-3 py-1.5 font-mono text-[11px] uppercase tracking-[0.28em] ${activeTool.accentClassName} border-current/20 bg-white/[0.02]`}>
                    {activeTool.icon}
                    {activeTool.subtitle}
                  </div>
                  <div>
                    <h1 className="font-display text-3xl font-black tracking-[-0.04em] text-white md:text-4xl">
                      选择想进入 {activeTool.title} 的藏品
                    </h1>
                    <p className="mt-3 max-w-3xl text-sm leading-7 text-neutral-400">
                      {activeTool.description} {activeTool.helper}
                    </p>
                  </div>
                </div>
              </div>

              <div className="rounded-[24px] border border-neutral-800 bg-black/25 px-4 py-4 text-sm text-neutral-300">
                <p>
                  当前可选 <span className="font-mono text-white">{activeTool.selectionLimit === 1 ? '1' : `1 - ${activeTool.selectionLimit}`}</span> 件藏品
                </p>
                <p className="mt-1 text-neutral-500">
                  已选择 <span className="font-mono text-white">{selectedItems.length}</span> 件
                </p>
              </div>
            </div>
          </section>

          <section className="rounded-[28px] border border-remuse-border bg-remuse-panel/85 p-4 shadow-[0_18px_48px_rgba(0,0,0,0.2)] md:p-5">
            <div className="mb-4 flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
              <div>
                <h2 className="font-display text-lg font-bold text-white">按藏品分类筛选</h2>
                <p className="mt-1 text-sm text-neutral-500">像相册一样挑选已经入馆的物品，再进入对应主线。</p>
              </div>
            </div>

            <div className="overflow-x-auto pb-2">
              <div className="flex min-w-full gap-2 md:flex-wrap">
                {filterOptions.map((option) => {
                  const active = option.id === selectedHallId || (option.id === null && selectedHallId === null);
                  return (
                    <button
                      key={option.id || 'all'}
                      type="button"
                      onClick={() => setSelectedHallId(option.id)}
                      className={`inline-flex min-h-[44px] items-center gap-2 rounded-full border px-4 py-2 text-sm transition-all ${
                        active
                          ? 'border-remuse-accent bg-remuse-accent text-black'
                          : 'border-neutral-700 bg-black/20 text-neutral-300 hover:border-white/30 hover:text-white'
                      }`}
                    >
                      <span className="whitespace-nowrap">{option.label}</span>
                      <span className={`rounded-full px-2 py-0.5 text-[11px] font-mono ${active ? 'bg-black/10' : 'bg-white/5 text-neutral-400'}`}>
                        {option.count}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </section>

          {filteredItems.length === 0 ? (
            <section className="flex min-h-[320px] flex-col items-center justify-center rounded-[28px] border border-dashed border-neutral-800 bg-remuse-panel/55 px-6 py-12 text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full border border-neutral-700 bg-black/20 text-neutral-500">
                <Box size={28} strokeWidth={1.6} />
              </div>
              <h2 className="mt-5 font-display text-2xl font-bold text-white">当前筛选下还没有藏品</h2>
              <p className="mt-3 max-w-md text-sm leading-7 text-neutral-400">
                试试切换分类，或者先去扫描仪与藏品馆补充更多内容。
              </p>
            </section>
          ) : (
            <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">
              {filteredItems.map((item) => {
                const selected = selectedItemIds.includes(item.id);
                const usable = canUseItem(item);
                const displayCoverUrl = item.coverImageUrl || item.imageUrl;
                const hallLabel = getHallNameById(safeHalls, item.hallId, item.category);

                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => usable && toggleItemSelection(item.id)}
                    disabled={!usable}
                    className={`group relative flex min-h-[340px] flex-col overflow-hidden rounded-[28px] border text-left transition-all ${
                      selected
                        ? 'border-remuse-accent bg-remuse-panel shadow-[0_0_0_1px_rgba(204,255,0,0.18),0_16px_44px_rgba(0,0,0,0.24)]'
                        : usable
                          ? 'border-remuse-border bg-remuse-panel hover:-translate-y-1 hover:border-white/30'
                          : 'cursor-not-allowed border-neutral-800 bg-neutral-950/70 opacity-55'
                    }`}
                  >
                    <div className="relative aspect-[4/3] overflow-hidden border-b border-white/5 bg-black/30">
                      {displayCoverUrl ? (
                        <img
                          src={displayCoverUrl}
                          alt={item.name}
                          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                        />
                      ) : (
                        <div className="flex h-full items-center justify-center text-neutral-500">
                          <ImageIcon size={32} />
                        </div>
                      )}
                      <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(0,0,0,0.04),rgba(0,0,0,0.36))]" />
                      <div className="absolute left-4 top-4 flex flex-wrap items-center gap-2">
                        <span className="rounded-full border border-white/10 bg-black/45 px-3 py-1 text-[11px] font-mono uppercase tracking-[0.22em] text-neutral-200">
                          {hallLabel}
                        </span>
                        {!usable ? (
                          <span className="rounded-full border border-red-400/20 bg-red-500/10 px-3 py-1 text-[11px] text-red-300">
                            缺少可用图片
                          </span>
                        ) : null}
                      </div>
                      {selected ? (
                        <div className="absolute right-4 top-4 flex h-10 w-10 items-center justify-center rounded-full bg-remuse-accent text-black shadow-[0_10px_30px_rgba(204,255,0,0.24)]">
                          <CheckCircle2 size={18} />
                        </div>
                      ) : null}
                    </div>

                    <div className="flex flex-1 flex-col justify-between gap-4 p-4">
                      <div>
                        <h3 className="line-clamp-2 font-display text-xl font-bold text-white">{item.name}</h3>
                        <p className="mt-2 line-clamp-2 text-sm leading-6 text-neutral-400">
                          {item.story?.trim() || '已归档，等待进入新的再生主线。'}
                        </p>
                      </div>

                      <div className="flex items-center justify-between gap-3 text-xs text-neutral-500">
                        <span className="font-mono uppercase tracking-[0.22em]">{formatCollectionDate(item.dateCollected)}</span>
                        <span className="line-clamp-1 text-right">{item.material || '未记录材质'}</span>
                      </div>
                    </div>
                  </button>
                );
              })}
            </section>
          )}

          <section className="sticky bottom-0 z-20 pt-2">
            <div className="rounded-[26px] border border-remuse-border bg-neutral-950/92 p-4 shadow-[0_16px_48px_rgba(0,0,0,0.28)] backdrop-blur-xl">
              <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div className="text-sm text-neutral-400">
                  {selectedItems.length > 0 ? (
                    <>
                      已选 <span className="font-mono text-white">{selectedItems.length}</span> 件藏品，准备进入
                      <span className={`ml-1 font-display font-bold ${activeTool.accentClassName}`}>{activeTool.title}</span>。
                    </>
                  ) : (
                    '先选择要进入当前主线的藏品。'
                  )}
                </div>

                <div className="flex flex-col gap-3 sm:flex-row">
                  <button
                    type="button"
                    onClick={closePicker}
                    className="inline-flex min-h-[46px] items-center justify-center rounded-full border border-neutral-700 px-5 text-sm text-neutral-300 transition-colors hover:border-white hover:text-white"
                  >
                    取消
                  </button>
                  <button
                    type="button"
                    onClick={handleLaunch}
                    disabled={selectedItems.length === 0 || isLaunching}
                    className="inline-flex min-h-[46px] items-center justify-center gap-2 rounded-full bg-remuse-accent px-5 text-sm font-display font-bold text-black transition-colors hover:bg-white disabled:cursor-not-allowed disabled:bg-neutral-800 disabled:text-neutral-500"
                  >
                    {isLaunching ? '正在准备素材...' : activeTool.cta}
                    <ArrowRight size={16} />
                  </button>
                </div>
              </div>
              {launchError ? <p className="mt-3 text-sm text-red-300">{launchError}</p> : null}
            </div>
          </section>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full overflow-y-auto bg-remuse-dark p-4 pb-24 md:p-8">
      <div className="mx-auto max-w-[1480px] space-y-6">
        <section className="overflow-hidden rounded-[32px] border border-remuse-border bg-[radial-gradient(circle_at_top_left,rgba(204,255,0,0.14),transparent_28%),radial-gradient(circle_at_top_right,rgba(34,211,238,0.14),transparent_28%),linear-gradient(180deg,rgba(18,20,25,0.98),rgba(9,11,15,0.98))] p-6 shadow-[0_24px_72px_rgba(0,0,0,0.3)] md:p-8">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 rounded-full border border-remuse-accent/25 bg-remuse-accent/10 px-3 py-1.5 font-mono text-[11px] uppercase tracking-[0.3em] text-remuse-accent">
                <Sparkles size={14} />
                Regeneration Workshop
              </div>
              <div>
                <h1 className="font-display text-3xl font-black tracking-[-0.04em] text-white md:text-5xl">
                  再生工坊
                </h1>
                <p className="mt-3 max-w-3xl text-sm leading-7 text-neutral-400 md:text-base">
                  把已经入馆的物品重新组织成三条再生主线。先像翻相册一样选藏品，再进入对应工坊继续创作。
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
              <div className="rounded-[22px] border border-white/8 bg-black/20 px-4 py-4">
                <p className="text-[11px] font-mono uppercase tracking-[0.26em] text-neutral-500">已入馆藏品</p>
                <p className="mt-2 font-display text-2xl font-black text-white">{safeItems.length}</p>
              </div>
              <div className="rounded-[22px] border border-white/8 bg-black/20 px-4 py-4">
                <p className="text-[11px] font-mono uppercase tracking-[0.26em] text-neutral-500">可做视觉再生</p>
                <p className="mt-2 font-display text-2xl font-black text-white">{visualReadyCount}</p>
              </div>
              <div className="rounded-[22px] border border-white/8 bg-black/20 px-4 py-4 col-span-2 md:col-span-1">
                <p className="text-[11px] font-mono uppercase tracking-[0.26em] text-neutral-500">已保存成果</p>
                <p className="mt-2 font-display text-2xl font-black text-white">
                  {resultStats.stickers + resultStats.emojiPacks + resultStats.perlerPatterns}
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="grid gap-5 xl:grid-cols-[1.2fr_1fr_1fr]">
          <article className={`rounded-[30px] border p-5 shadow-[0_18px_56px_rgba(0,0,0,0.24)] md:p-6 ${TOOL_CONFIGS.EMOJI_PACK.panelClassName}`}>
            <div className="flex flex-col gap-6 h-full">
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-3">
                  <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-black/15 px-3 py-1 text-[11px] font-mono uppercase tracking-[0.26em] text-neutral-300">
                    <Sparkles size={14} />
                    妙趣灵感社
                  </span>
                  <div>
                    <h2 className="font-display text-3xl font-black tracking-[-0.04em] text-white">收集可爱与创意</h2>
                    <p className="mt-3 max-w-xl text-sm leading-7 text-neutral-300/80">
                      把物品的视觉性格转成更轻盈的表达，适合生成表情包、拼豆图纸等更有趣的再生载体。
                    </p>
                  </div>
                </div>
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-black/20 text-amber-300">
                  <Smile size={24} />
                </div>
              </div>

              <div className="grid gap-3 md:grid-cols-2">
                <button
                  type="button"
                  onClick={() => openPicker('EMOJI_PACK')}
                  className="rounded-[24px] border border-white/10 bg-black/15 p-4 text-left transition-all hover:-translate-y-1 hover:border-amber-300/40 hover:bg-black/25"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div className="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-400/18 text-amber-300">
                      <Smile size={20} />
                    </div>
                    <ArrowRight size={18} className="text-neutral-400" />
                  </div>
                  <h3 className="mt-4 font-display text-xl font-bold text-white">表情包</h3>
                  <p className="mt-2 text-sm leading-6 text-neutral-400">基于藏品气质生成更适合分享和表达心情的表情包素材。</p>
                </button>

                <button
                  type="button"
                  onClick={() => openPicker('PERLER_PATTERN')}
                  className="rounded-[24px] border border-white/10 bg-black/15 p-4 text-left transition-all hover:-translate-y-1 hover:border-cyan-300/40 hover:bg-black/25"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div className="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-cyan-400/18 text-cyan-300">
                      <Box size={20} />
                    </div>
                    <ArrowRight size={18} className="text-neutral-400" />
                  </div>
                  <h3 className="mt-4 font-display text-xl font-bold text-white">拼豆图纸</h3>
                  <p className="mt-2 text-sm leading-6 text-neutral-400">把单件藏品转成可继续制作与导出的拼豆像素图纸。</p>
                </button>
              </div>
            </div>
          </article>

          <article className={`rounded-[30px] border p-5 shadow-[0_18px_56px_rgba(0,0,0,0.24)] md:p-6 ${TOOL_CONFIGS.PRINT.panelClassName}`}>
            <div className="flex flex-col gap-6 h-full">
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-3">
                  <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-black/15 px-3 py-1 text-[11px] font-mono uppercase tracking-[0.26em] text-neutral-300">
                    <Heart size={14} />
                    心灵自留地
                  </span>
                  <div>
                    <h2 className="font-display text-3xl font-black tracking-[-0.04em] text-white">安放情绪与温柔</h2>
                    <p className="mt-3 text-sm leading-7 text-neutral-300/80">
                      为已经入馆的物品编织一页更安静、更贴近自己的手账拼贴。
                    </p>
                  </div>
                </div>
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-black/20 text-sky-300">
                  <Scissors size={24} />
                </div>
              </div>

              <button
                type="button"
                onClick={() => openPicker('PRINT')}
                className="mt-auto rounded-[24px] border border-white/10 bg-black/15 p-4 text-left transition-all hover:-translate-y-1 hover:border-sky-300/40 hover:bg-black/25"
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-sky-400/18 text-sky-300">
                    <Scissors size={20} />
                  </div>
                  <ArrowRight size={18} className="text-neutral-400" />
                </div>
                <h3 className="mt-4 font-display text-xl font-bold text-white">手账拼贴</h3>
                <p className="mt-2 text-sm leading-6 text-neutral-400">多件藏品一起进入，整理成适合继续排版与输出的手账页面。</p>
              </button>
            </div>
          </article>

          <article className={`rounded-[30px] border p-5 shadow-[0_18px_56px_rgba(0,0,0,0.24)] md:p-6 ${TOOL_CONFIGS.GUIDE.panelClassName}`}>
            <div className="flex flex-col gap-6 h-full">
              <div className="flex items-start justify-between gap-4">
                <div className="space-y-3">
                  <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-black/15 px-3 py-1 text-[11px] font-mono uppercase tracking-[0.26em] text-neutral-300">
                    <Hammer size={14} />
                    旧物新生局
                  </span>
                  <div>
                    <h2 className="font-display text-3xl font-black tracking-[-0.04em] text-white">让旧物继续陪伴你</h2>
                    <p className="mt-3 text-sm leading-7 text-neutral-300/80">
                      从单件物品出发，继续编辑故事、生成改造方案，并推进它的再生状态。
                    </p>
                  </div>
                </div>
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-black/20 text-remuse-accent">
                  <Hammer size={24} />
                </div>
              </div>

              <button
                type="button"
                onClick={() => openPicker('GUIDE')}
                className="mt-auto rounded-[24px] border border-white/10 bg-black/15 p-4 text-left transition-all hover:-translate-y-1 hover:border-remuse-accent/40 hover:bg-black/25"
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="inline-flex h-11 w-11 items-center justify-center rounded-2xl bg-remuse-accent/18 text-remuse-accent">
                    <Hammer size={20} />
                  </div>
                  <ArrowRight size={18} className="text-neutral-400" />
                </div>
                <h3 className="mt-4 font-display text-xl font-bold text-white">改造指南</h3>
                <p className="mt-2 text-sm leading-6 text-neutral-400">单件进入，沿着现有再生协议继续推进成品方向。</p>
              </button>
            </div>
          </article>
        </section>

        <section className="rounded-[28px] border border-remuse-border bg-remuse-panel/80 p-5 shadow-[0_18px_48px_rgba(0,0,0,0.2)] md:p-6">
          <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full border border-neutral-700 bg-black/20 px-3 py-1.5 text-[11px] font-mono uppercase tracking-[0.28em] text-neutral-400">
                <StickerIcon size={14} />
                再生成果库
              </div>
              <h2 className="mt-4 font-display text-2xl font-bold text-white">继续整理已经生成的成果</h2>
              <p className="mt-2 max-w-2xl text-sm leading-7 text-neutral-400">
                贴纸、表情包、拼豆图纸都会继续保存在成果库里。你可以随时回去二次编辑、导出或删除。
              </p>
            </div>

            <div className="flex flex-col gap-3 sm:flex-row">
              <div className="rounded-[22px] border border-neutral-800 bg-black/25 px-4 py-4 text-sm text-neutral-300">
                贴纸 <span className="font-mono text-white">{resultStats.stickers}</span> · 表情包 <span className="font-mono text-white">{resultStats.emojiPacks}</span> · 拼豆图纸 <span className="font-mono text-white">{resultStats.perlerPatterns}</span>
              </div>
              <button
                type="button"
                onClick={onOpenLibrary}
                className="inline-flex min-h-[46px] items-center justify-center gap-2 rounded-full border border-neutral-700 px-5 text-sm text-neutral-200 transition-colors hover:border-white hover:text-white"
              >
                打开成果库
                <ArrowRight size={16} />
              </button>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default RegenerationWorkshop;
